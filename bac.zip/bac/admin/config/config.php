<?php
	$SITE_CONFIG['SERVER_URL'] = 'localhost';
php?>