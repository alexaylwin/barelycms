<?php
	include 'header.php';
?>
<style type="text/css">

</style>

<h4>Buckets</h4>
<div class="tabbedContainer">

	<div class="leftContainer">
		<ul>
			<li>Bucket 1</li>
			<li>Bucket 2</li>
			<li>Bucket 3</li>
		</ul>	
	</div>
	
	<div class="rightContainer">
		<ul>
			<li>Block1</li>
			<li>Block2</li>
			<li>Block3</li>
		</ul>
	</div>

</div>

<?php
	include 'footer.php';
?>