				</div>
			</div>
		</div>
		<div class="navbar navbar-fixed-bottom" id="footer">
			<p class="text-center">(c) 2013 Alex Aylwin | <a href="http://github.com/alexaylwin/barelyacms">BarelyACMS</a></p> 
    	</div>
	</div>
</body>
</html>